#!/bin/bash

## install depend
yum -y update
yum -y install git automake byacc ncurses-devel gcc ncurses
cd libevent-2.1.8-stable
./configure
make -j8
make install
ln -s /usr/local/lib/libevent_core-2.1.so.6 /usr/lib64/libevent_core-2.1.so.6
cd ../

## tmux install
cd tmux
sh autogen.sh
./configure 
make -j8
make install
cd ../


###reference

### 升級tmux1.8至最新
# https://www.796t.com/content/1549951778.html

### 升級tmux 相關依賴問題
# https://blog.csdn.net/liguangxianbin/article/details/79742642
# https://blog.csdn.net/u011046042/article/details/128567043?utm_medium=distribute.pc_feed_404.none-task-blog-2~default~BlogCommendFromBaidu~PayColumn-1-128567043-blog-null.262^v1^pc_404_mixedpudn&depth_1-utm_source=distribute.pc_feed_404.none-task-blog-2~default~BlogCommendFromBaidu~PayColumn-1-128567043-blog-null.262^v1^pc_404_mixedpud
# https://github.com/No5stranger/cjp-tmux/issues/1
# https://blog.csdn.net/yesuhuangsi/article/details/100543261

### tmux 升級後版本衝突解決辦法
# https://blog.longwin.com.tw/2013/11/tmux-protocol-version-mismatch-fix-2013/

