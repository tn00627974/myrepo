#!/bin/bash

## tmux plugins
mkdir -p ~/.tmux/plugins
cp -a tpm ~/.tmux/plugins/tpm
cp -a tmux.conf ~/.tmux.conf

## set plugins
## prefix == control + b 
#  tmux
#  prefix + d
#  tmux source ~/.tmux.conf 
#  vi .tmux.conf and take off #
#  tmux
#  prefix I (control b + I)

##reference
##http://rightson.blogspot.com/2016/05/tmux-plugins.html
